export type Marketplace = {
  id: string
  name: string
  icon: string
  domain: string
}

export const MARKETPLACES: Marketplace[] = [
  {
    id: "coupang",
    name: "쿠팡",
    icon: "/marketplace/coupang.png",
    domain: "coupang.com",
  },
  {
    id: "naver",
    name: "네이버쇼핑",
    icon: "/marketplace/naver.png",
    domain: "shopping.naver.com",
  },
  {
    id: "11st",
    name: "11번가",
    icon: "/marketplace/11st.png",
    domain: "11st.co.kr",
  },
  {
    id: "gmarket",
    name: "G마켓",
    icon: "/marketplace/gmarket.png",
    domain: "gmarket.co.kr",
  },
]

