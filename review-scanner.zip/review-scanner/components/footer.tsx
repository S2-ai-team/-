import Image from "next/image"

export function Footer() {
  return (
    <footer className="fixed bottom-0 w-full bg-gray-50 py-3 text-center text-sm text-gray-600 transition-opacity duration-500 ease-in-out">
      <p>Contact us: harry.srobot.2011@gmail.com</p>
      <p>REVIEW SCANNER.</p>
      <Image src="/pear.png" alt="Pear Logo" width={30} height={30} className="mx-auto mt-2" />
    </footer>
  )
}

