"use client"

import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Search, Bot, Star, PenLine } from "lucide-react"

export function SearchModes() {
  const router = useRouter()

  return (
    <div className="w-full max-w-6xl px-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="hover:shadow-lg transition-shadow cursor-pointer">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bot className="h-5 w-5 text-blue-500" />
              AI 검색
            </CardTitle>
            <CardDescription>AI 기반 리뷰 분석으로 더 정확한 결과를 확인하세요</CardDescription>
          </CardHeader>
          <CardContent>
            <Badge variant="secondary" className="mb-2">
              신규
            </Badge>
            <p className="text-sm text-muted-foreground">머신러닝 알고리즘을 통한 감성 분석 및 키워드 추출</p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow cursor-pointer">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5 text-green-500" />
              일반 검색
            </CardTitle>
            <CardDescription>빠르고 정확한 리뷰 검색 결과를 제공합니다</CardDescription>
          </CardHeader>
          <CardContent>
            <Badge variant="secondary" className="mb-2">
              기본
            </Badge>
            <p className="text-sm text-muted-foreground">정확한 키워드 매칭으로 원하는 리뷰를 빠르게 찾아보세요</p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow cursor-pointer">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="h-5 w-5 text-yellow-500" />
              리뷰 분석
            </CardTitle>
            <CardDescription>상세한 리뷰 분석 결과를 확인하세요</CardDescription>
          </CardHeader>
          <CardContent>
            <Badge variant="secondary" className="mb-2">
              프리미엄
            </Badge>
            <p className="text-sm text-muted-foreground">리뷰 트렌드와 상세 분석 데이터를 한눈에 파악</p>
          </CardContent>
        </Card>
      </div>

      {/* Review Button */}
      <div className="mt-8 text-center">
        <Button size="lg" onClick={() => router.push("/write-review")} className="gap-2">
          <PenLine className="h-5 w-5" />
          리뷰 작성하기
        </Button>
      </div>
    </div>
  )
}

