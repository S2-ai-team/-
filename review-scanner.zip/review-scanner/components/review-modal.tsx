"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { submitReview } from "@/app/actions/review"
import { useToast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"

interface ReviewModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function ReviewModal({ open, onOpenChange }: ReviewModalProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setIsSubmitting(true)

    const formData = new FormData(event.currentTarget)
    const result = await submitReview(formData)

    if (result.error) {
      toast({
        variant: "destructive",
        title: "오류",
        description: result.error,
      })
    } else {
      toast({
        title: "성공",
        description: "리뷰가 성공적으로 등록되었습니다.",
      })
      onOpenChange(false)
    }

    setIsSubmitting(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>리뷰 작성하기</DialogTitle>
          <DialogDescription>제품 URL을 입력하시면 AI가 자동으로 제품 정보를 수집합니다.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="productUrl" className="text-sm font-medium">
              제품 URL
            </label>
            <Input id="productUrl" name="productUrl" placeholder="https://..." required />
          </div>
          <div className="space-y-2">
            <label htmlFor="review" className="text-sm font-medium">
              리뷰 내용
            </label>
            <Textarea
              id="review"
              name="review"
              placeholder="이 제품에 대한 리뷰를 작성해주세요..."
              required
              className="min-h-[100px]"
            />
          </div>
          <Button type="submit" className="w-full" disabled={isSubmitting}>
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                제출 중...
              </>
            ) : (
              "리뷰 등록하기"
            )}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  )
}

