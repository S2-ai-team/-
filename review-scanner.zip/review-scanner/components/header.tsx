"use client"

import { useState, type React } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"

export function Header() {
  const router = useRouter()
  const [searchValue, setSearchValue] = useState("")

  const handleSearch = (e?: React.FormEvent) => {
    e?.preventDefault()
    if (searchValue.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchValue.trim())}`)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && searchValue.trim()) {
      handleSearch()
    }
  }

  return (
    <header className="fixed top-0 w-full bg-white transition-opacity duration-500 ease-in-out z-50">
      <div className="container mx-auto px-4 py-6 text-center">
        <Image
          src="/logo.png"
          alt="Review Scanner Logo"
          width={200}
          height={60}
          className="mx-auto cursor-pointer"
          priority
          onClick={() => router.push("/")}
        />
        <form onSubmit={handleSearch} className="mt-6 flex items-center justify-center gap-2">
          <Input
            type="text"
            placeholder="검색어를 입력하세요 . . ."
            className="max-w-xl rounded-full"
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            onKeyDown={handleKeyDown}
          />
          <Button type="submit" size="icon" variant="ghost" disabled={!searchValue.trim()}>
            <Search className="h-5 w-5" />
          </Button>
        </form>
      </div>
    </header>
  )
}

