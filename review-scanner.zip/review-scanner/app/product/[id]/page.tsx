import Image from "next/image"
import type { Metadata } from "next"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Star, ThumbsUp, MessageCircle, BarChart2 } from "lucide-react"
import { MARKETPLACES } from "@/types/marketplace"

export const metadata: Metadata = {
  title: "상품 상세 | REVIEW SCANNER",
}

interface ReviewProps {
  id: string
  author: string
  rating: number
  content: string
  date: string
  helpful: number
  sentiment: "positive" | "negative" | "neutral"
}

const DUMMY_REVIEWS: ReviewProps[] = [
  {
    id: "1",
    author: "리뷰어1",
    rating: 5,
    content: "정말 좋은 제품입니다. 배송도 빠르고 품질도 훌륭해요.",
    date: "2024-02-10",
    helpful: 12,
    sentiment: "positive",
  },
  {
    id: "2",
    author: "리뷰어2",
    rating: 3,
    content: "보통이에요. 가격 대비 괜찮은 것 같습니다.",
    date: "2024-02-09",
    helpful: 5,
    sentiment: "neutral",
  },
]

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-1">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} className={`h-4 w-4 ${i < rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`} />
      ))}
    </div>
  )
}

function ReviewCard({ review }: { review: ReviewProps }) {
  const sentimentColors = {
    positive: "text-green-600",
    negative: "text-red-600",
    neutral: "text-gray-600",
  }

  return (
    <Card className="p-4">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-medium">{review.author}</span>
            <StarRating rating={review.rating} />
          </div>
          <div className="text-sm text-gray-500">{review.date}</div>
        </div>
        <span className={`text-sm ${sentimentColors[review.sentiment]}`}>
          {review.sentiment === "positive" ? "긍정적" : review.sentiment === "negative" ? "부정적" : "중립적"}
        </span>
      </div>
      <p className="mt-2">{review.content}</p>
      <div className="mt-4 flex items-center gap-4">
        <Button variant="ghost" size="sm">
          <ThumbsUp className="h-4 w-4 mr-1" />
          도움됨 {review.helpful}
        </Button>
        <Button variant="ghost" size="sm">
          <MessageCircle className="h-4 w-4 mr-1" />
          댓글
        </Button>
      </div>
    </Card>
  )
}

export default function ProductPage() {
  const marketplace = MARKETPLACES[0] // 예시로 첫 번째 마켓플레이스 사용

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Product Info */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-8">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="relative aspect-square">
              <Image src="/placeholder.svg" alt="Product Image" fill className="object-cover rounded-lg" />
            </div>
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Image src={marketplace.icon || "/placeholder.svg"} alt={marketplace.name} width={24} height={24} />
                <span className="text-sm text-gray-600">{marketplace.name}</span>
              </div>
              <h1 className="text-2xl font-bold">상품명</h1>
              <div className="flex items-center gap-2">
                <StarRating rating={4.5} />
                <span className="text-lg font-semibold">4.5</span>
                <span className="text-sm text-gray-600">(32 리뷰)</span>
              </div>
              <div className="text-2xl font-bold">39,900원</div>
              <Button className="w-full" size="lg">
                구매하기
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Reviews & Analysis */}
      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="reviews">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="reviews">
              <MessageCircle className="h-4 w-4 mr-2" />
              리뷰
            </TabsTrigger>
            <TabsTrigger value="analysis">
              <BarChart2 className="h-4 w-4 mr-2" />
              AI 분석
            </TabsTrigger>
          </TabsList>
          <TabsContent value="reviews" className="mt-6">
            <div className="space-y-4">
              {DUMMY_REVIEWS.map((review) => (
                <ReviewCard key={review.id} review={review} />
              ))}
            </div>
          </TabsContent>
          <TabsContent value="analysis" className="mt-6">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">AI 분석 결과</h3>
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">감성 분석</h4>
                  <div className="flex items-center gap-4">
                    <div className="flex-1 bg-gray-100 rounded-full h-4">
                      <div className="bg-green-500 h-full rounded-full" style={{ width: "75%" }} />
                    </div>
                    <span className="text-sm">75% 긍정적</span>
                  </div>
                </div>
                <div>
                  <h4 className="font-medium mb-2">주요 키워드</h4>
                  <div className="flex flex-wrap gap-2">
                    {["품질", "가성비", "디자인", "배송", "서비스"].map((keyword) => (
                      <span key={keyword} className="px-3 py-1 bg-gray-100 rounded-full text-sm">
                        {keyword}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="font-medium mb-2">개선 제안사항</h4>
                  <p className="text-sm text-gray-600">
                    배송 속도와 포장 상태에 대한 불만이 있습니다. 배송 프로세스 개선이 필요해 보입니다.
                  </p>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

