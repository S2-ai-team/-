"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { MARKETPLACES } from "@/types/marketplace"
import { Bot, Search, ArrowLeft, LinkIcon } from "lucide-react"

const STEPS = [
  { id: "marketplace", title: "판매처 선택" },
  { id: "product", title: "상품 검색" },
  { id: "review", title: "리뷰 작성" },
  { id: "analysis", title: "AI 분석" },
]

export default function WriteReview() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(0)
  const [selectedMarketplace, setSelectedMarketplace] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [productUrl, setProductUrl] = useState("")
  const [review, setReview] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisResult, setAnalysisResult] = useState<string | null>(null)

  const progress = ((currentStep + 1) / STEPS.length) * 100

  const handleMarketplaceSelect = (marketplaceId: string) => {
    setSelectedMarketplace(marketplaceId)
    setCurrentStep(1)
  }

  const handleProductSearch = async () => {
    // 실제 구현에서는 여기에 상품 검색 API 호출
    setCurrentStep(2)
  }

  const handleReviewSubmit = async () => {
    setCurrentStep(3)
    setIsAnalyzing(true)

    try {
      // 실제 구현에서는 여기에 AI 분석 API 호출
      await new Promise((resolve) => setTimeout(resolve, 2000))
      setAnalysisResult("AI 분석이 완료되었습니다.")
    } catch (error) {
      setAnalysisResult("분석 중 오류가 발생했습니다.")
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="font-semibold">리뷰 작성하기</div>
          <div className="w-10" /> {/* Spacer */}
        </div>
      </header>

      {/* Progress */}
      <div className="container mx-auto px-4 py-4">
        <Progress value={progress} className="h-2" />
        <div className="flex justify-between mt-2 text-sm text-gray-600">
          {STEPS.map((step, index) => (
            <div key={step.id} className={`${index === currentStep ? "text-primary font-medium" : ""}`}>
              {step.title}
            </div>
          ))}
        </div>
      </div>

      {/* Content */}
      <main className="container mx-auto px-4 py-8">
        {currentStep === 0 && (
          <div className="grid grid-cols-2 gap-4">
            {MARKETPLACES.map((marketplace) => (
              <Button
                key={marketplace.id}
                variant="outline"
                className={`h-32 flex flex-col items-center justify-center gap-2 ${
                  selectedMarketplace === marketplace.id ? "border-primary" : ""
                }`}
                onClick={() => handleMarketplaceSelect(marketplace.id)}
              >
                <Image src={marketplace.icon || "/placeholder.svg"} alt={marketplace.name} width={40} height={40} />
                <span>{marketplace.name}</span>
              </Button>
            ))}
          </div>
        )}

        {currentStep === 1 && (
          <div className="space-y-4">
            <div className="flex gap-2">
              <Input
                placeholder="상품명을 입력하세요"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Button onClick={handleProductSearch}>
                <Search className="h-4 w-4 mr-2" />
                검색
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {/* 상품 검색 결과가 여기에 표시됩니다 */}
              {/* 예시 상품 */}
              <Button
                variant="outline"
                className="h-40 flex flex-col items-center justify-center gap-2"
                onClick={() => {
                  setProductUrl("https://example.com/product")
                  setCurrentStep(2)
                }}
              >
                <Image src="/placeholder.svg" alt="Product" width={100} height={100} className="rounded" />
                <div className="text-sm">상품명</div>
                <div className="flex items-center gap-1 text-xs text-gray-500">
                  <Image
                    src={MARKETPLACES[0].icon || "/placeholder.svg"}
                    alt={MARKETPLACES[0].name}
                    width={16}
                    height={16}
                  />
                  <span>{MARKETPLACES[0].name}</span>
                </div>
              </Button>
            </div>
          </div>
        )}

        {currentStep === 2 && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 p-4 bg-white rounded-lg border">
              <LinkIcon className="h-4 w-4 text-gray-400" />
              <div className="flex-1 truncate">{productUrl}</div>
            </div>
            <Textarea
              placeholder="이 제품에 대한 리뷰를 작성해주세요..."
              value={review}
              onChange={(e) => setReview(e.target.value)}
              className="min-h-[200px]"
            />
            <Button className="w-full" onClick={handleReviewSubmit} disabled={!review.trim()}>
              리뷰 제출하기
            </Button>
          </div>
        )}

        {currentStep === 3 && (
          <div className="space-y-4 text-center">
            {isAnalyzing ? (
              <div className="flex flex-col items-center gap-4">
                <Bot className="h-12 w-12 animate-pulse text-primary" />
                <div className="text-lg font-medium">AI가 리뷰를 분석하고 있습니다...</div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="text-lg font-medium">{analysisResult}</div>
                <Button onClick={() => router.push("/")} className="w-full">
                  완료
                </Button>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  )
}

