"use client"

import { Header } from "@/components/header"
import { SearchModes } from "@/components/search-modes"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="min-h-screen">
      <Button
        variant="secondary"
        className="fixed right-4 top-4 z-50"
        onClick={() => window.open("https://litt.ly/review_scanner", "_blank")}
      >
        About us
      </Button>

      <Header />

      <main className="flex min-h-screen items-center justify-center pt-48 pb-32">
        <SearchModes />
      </main>

      <Footer />
    </div>
  )
}

