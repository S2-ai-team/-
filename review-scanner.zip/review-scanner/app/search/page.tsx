"use client"

import { useSearchParams, useRouter } from "next/navigation"
import Image from "next/image"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Star, Search } from "lucide-react"
import { MARKETPLACES } from "@/types/marketplace"
import type React from "react" // Added import for React

interface Product {
  id: string
  name: string
  price: number
  rating: number
  reviewCount: number
  image: string
  marketplace: string
}

// 더미 데이터
const DUMMY_PRODUCTS: Product[] = [
  {
    id: "1",
    name: "샘플 제품 1",
    price: 29900,
    rating: 4.5,
    reviewCount: 128,
    image: "/placeholder.svg",
    marketplace: "coupang",
  },
  {
    id: "2",
    name: "샘플 제품 2",
    price: 39900,
    rating: 4.2,
    reviewCount: 56,
    image: "/placeholder.svg",
    marketplace: "naver",
  },
  // ... 더 많은 제품 추가
]

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-1">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={`h-4 w-4 ${i < Math.floor(rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
        />
      ))}
      <span className="text-sm text-gray-600 ml-1">{rating}</span>
    </div>
  )
}

function formatPrice(price: number) {
  return new Intl.NumberFormat("ko-KR").format(price)
}

function ProductCard({ product }: { product: Product }) {
  const router = useRouter()
  const marketplace = MARKETPLACES.find((m) => m.id === product.marketplace)

  return (
    <Card
      className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow"
      onClick={() => router.push(`/product/${product.id}`)}
    >
      <div className="relative aspect-square">
        <Image src={product.image || "/placeholder.svg"} alt={product.name} fill className="object-cover" />
      </div>
      <div className="p-4">
        <div className="flex items-center gap-2 mb-2">
          {marketplace && (
            <Image src={marketplace.icon || "/placeholder.svg"} alt={marketplace.name} width={16} height={16} />
          )}
          <span className="text-sm text-gray-600">{marketplace?.name}</span>
        </div>
        <h3 className="font-medium mb-2 line-clamp-2">{product.name}</h3>
        <div className="flex items-center justify-between">
          <div className="font-bold">{formatPrice(product.price)}원</div>
          <div className="text-sm text-gray-600">리뷰 {product.reviewCount}</div>
        </div>
        <div className="mt-2">
          <StarRating rating={product.rating} />
        </div>
      </div>
    </Card>
  )
}

export default function SearchPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const query = searchParams.get("q") || ""

  const handleSearch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    const searchQuery = formData.get("search") as string
    if (searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Search Header */}
      <div className="sticky top-0 bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <form onSubmit={handleSearch} className="flex gap-2 max-w-2xl mx-auto">
            <Input name="search" defaultValue={query} placeholder="검색어를 입력하세요..." className="flex-1" />
            <Button type="submit">
              <Search className="h-4 w-4 mr-2" />
              검색
            </Button>
          </form>
        </div>
      </div>

      {/* Results */}
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-2">"{query}" 검색 결과</h1>
          <p className="text-gray-600">{DUMMY_PRODUCTS.length}개의 제품이 검색되었습니다.</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {DUMMY_PRODUCTS.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  )
}

